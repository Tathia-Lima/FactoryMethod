package factoryMethod;

public class PagamentoTransferencia {
    public String realizarPagamento() {

        return "Pagamento com transferência realizado";
    }

    public String cancelarPagamento() {

        return "Pagamento com transferência cancelado";
    }
}
