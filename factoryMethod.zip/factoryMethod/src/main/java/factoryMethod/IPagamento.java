package factoryMethod;

public interface IPagamento {
    String realizarPagamento();
    String cancelarPagamento();
}
